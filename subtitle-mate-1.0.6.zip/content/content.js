// SubtitleMate content script (isolated world).
// Orchestrates caption/translation by delegating player-API work to
// content/bridge.js, which runs in the page's main world and can access
// YouTube's internal window.yt.player API.  Communication is done via
// window.postMessage.

(function () {
  'use strict';

  console.log('[SubtitleMate] content script loaded v' +
    (chrome.runtime && chrome.runtime.getManifest && chrome.runtime.getManifest().version || '?'));

  const K = {
    AUTO_CAPTIONS: 'sm_autoCaptions',
    CAPTION_MODE: 'sm_captionMode',
    TARGET_LANG: 'sm_targetLang',
    AUTO_ON_YT: 'sm_autoOnYt',
    AUTO_TRANSLATE: 'sm_autoTranslate',
    AUTO_PLAYBACK_SPEED: 'sm_autoPlaybackSpeed',
    PLAYBACK_RATE: 'sm_playbackRate',
    RETRY_COUNT: 'sm_retryCount',
  };

  const MODE = {
    TRANSLATE: 'translate',
    AUTO_GENERATED: 'auto-generated',
    ORIGINAL: 'original', // captions on, no translation
  };

  let settings = null;
  let applied = false;
  let appliedVideoId = null;   // per-video guard: which video id we already applied to
  let speedApplied = false;    // whether we already set the playback speed for this video
  let applying = false;        // re-entrancy lock wrapping APPLY / SET_PLAYBACK_RATE
  let running = false;
  let bridgeReady = false;
  let navigateDebounceTimer = null;
  let currentRunToken = null;  // abort token for the active retry loop
  let pendingRun = false;      // whether a new run was requested while one was active

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  async function loadSettings() {
    const defs = {
      [K.AUTO_CAPTIONS]: true,
      [K.CAPTION_MODE]: MODE.TRANSLATE,
      [K.TARGET_LANG]: 'zh-CN',
      [K.AUTO_ON_YT]: true,
      [K.AUTO_TRANSLATE]: true,
      [K.AUTO_PLAYBACK_SPEED]: false,
      [K.PLAYBACK_RATE]: 1.5,
      [K.RETRY_COUNT]: 5,
    };
    settings = await chrome.storage.sync.get(defs);
  }

  function isEnabled() {
    return !!settings && settings[K.AUTO_CAPTIONS] && settings[K.AUTO_ON_YT];
  }

  // ---------- bridge injection ----------

  function injectBridge() {
    if (document.getElementById('subtitlemate-bridge-script')) return true;
    if (!chrome.runtime || !chrome.runtime.getURL) return false;
    const s = document.createElement('script');
    s.id = 'subtitlemate-bridge-script';
    s.src = chrome.runtime.getURL('content/bridge.js');
    s.async = true;
    s.onload = () => console.log('[SubtitleMate] bridge script injected');
    s.onerror = () => console.log('[SubtitleMate] bridge script failed to load');
    const root = document.head || document.documentElement;
    if (!root) return false;
    root.appendChild(s);
    return true;
  }

  async function waitForBridge(maxMs = 3000) {
    if (bridgeReady) return true;
    const deadline = Date.now() + maxMs;
    while (Date.now() < deadline) {
      if (bridgeReady) return true;
      await sleep(100);
    }
    return false;
  }

  function sendBridgeCommand(type, payload, timeout = 8000) {
    return new Promise((resolve) => {
      const id = Math.random().toString(36).slice(2) + Date.now();
      const handler = (event) => {
        const data = event.data;
        if (!data || data.source !== 'subtitlemate-bridge') return;
        if (data.type === 'RESULT' && data.id === id) {
          window.removeEventListener('message', handler);
          resolve(data.payload || { ok: false, info: 'empty result' });
        }
      };
      window.addEventListener('message', handler);
      window.postMessage({ source: 'subtitlemate-content', type, id, payload }, '*');
      setTimeout(() => {
        window.removeEventListener('message', handler);
        resolve({ ok: false, info: 'bridge command timeout' });
      }, timeout);
    });
  }

  // ---------- state comparison ----------

  function stateMatchesTarget(st, mode, targetCode) {
    if (!st || !st.ok) return !!st.panelSatisfied;
    if (st.panelSatisfied) return true;
    if (mode === MODE.ORIGINAL) {
      // Any original (non-translated) caption track is acceptable.
      if (st.isTranslation) return false;
    } else if (mode === MODE.AUTO_GENERATED) {
      // Expect an English base track with no translation.
      if (!st.baseLang || st.baseLang.indexOf('en') !== 0) return false;
      if (st.isTranslation) return false;
    } else {
      // Expect a track translated into the chosen language.
      if (!st.isTranslation) return false;
      if (st.translationLanguage !== (targetCode || 'zh-CN').toLowerCase()) return false;
    }
    return true;
  }

  function speedMatchesTarget(st) {
    if (!st || !st.ok || !settings[K.AUTO_PLAYBACK_SPEED]) return true;
    const targetRate = Number(settings[K.PLAYBACK_RATE]) || 1.5;
    if (typeof st.playbackRate !== 'number') return false;
    return Math.abs(st.playbackRate - targetRate) < 0.01;
  }

  // ---------- main flow ----------

  async function applyOnce() {
    const token = currentRunToken;
    if (!token || token.aborted) return;

    // Re-entrancy lock: never run two APPLY/SET_PLAYBACK_RATE sequences at once.
    if (applying) return;
    // Per-video guard: if we already applied to the current video, do nothing.
    if (applied && appliedVideoId === currentVideoId()) return;
    if (!isEnabled()) {
      console.log('[SubtitleMate] skipped: disabled');
      return;
    }

    applying = true;
    try {
      injectBridge();
      const bridgeOk = await waitForBridge(3000);
      if (!bridgeOk) {
        console.log('[SubtitleMate] bridge not ready, will retry');
        return;
      }
      if (token.aborted) {
        console.log('[SubtitleMate] applyOnce aborted after bridge ready');
        return;
      }

      // Auto-translate off forces original-captions mode regardless of the
      // caption-mode dropdown: "show captions, don't translate them".
      const autoTranslate = settings[K.AUTO_TRANSLATE] !== false;
      const mode = autoTranslate
        ? settings[K.CAPTION_MODE]
        : MODE.ORIGINAL;
      const targetCode = settings[K.TARGET_LANG] || 'zh-CN';
      console.log('[SubtitleMate] applyOnce mode=' + mode + ' target=' + targetCode);

      // Read the current state (captions + speed) before deciding what to do.
      const currentState = await sendBridgeCommand('GET_STATE', { mode: mode, targetLang: targetCode }, 5000);
      if (token.aborted) {
        console.log('[SubtitleMate] applyOnce aborted after state read');
        return;
      }
      console.log('[SubtitleMate] current state -> ' + JSON.stringify(currentState));

      // STEP 1 — playback speed FIRST, independent of whether the video has
      // any captions. Videos with no subtitles still get their speed applied.
      if (settings && settings[K.AUTO_PLAYBACK_SPEED] && !speedApplied && !speedMatchesTarget(currentState)) {
        const rate = Number(settings[K.PLAYBACK_RATE]) || 1.5;
        const sr = await sendBridgeCommand('SET_PLAYBACK_RATE', { rate }, 8000);
        if (token.aborted) {
          console.log('[SubtitleMate] applyOnce aborted after speed result');
          return;
        }
        console.log('[SubtitleMate] playback rate result -> ' + JSON.stringify(sr));
        if (sr && sr.ok) speedApplied = true;
      }

      // STEP 2 — captions. If the target is already satisfied we are done;
      // the speed was handled above in step 1.
      if (stateMatchesTarget(currentState, mode, targetCode)) {
        const speedSettled = !settings[K.AUTO_PLAYBACK_SPEED] || speedApplied || speedMatchesTarget(currentState);
        if (speedSettled) {
          applied = true;
          appliedVideoId = currentVideoId();
          try { observer.disconnect(); } catch (_) {}
          console.log('[SubtitleMate] success: captions already satisfy target; no action needed');
        } else {
          console.log('[SubtitleMate] captions already correct, waiting for speed to settle');
        }
        return;
      }

      // STEP 3 — attempt to apply captions / translation.
      const result = await sendBridgeCommand('APPLY', {
        mode: mode,
        targetLang: targetCode,
      }, 30000);
      if (token.aborted) {
        console.log('[SubtitleMate] applyOnce aborted after APPLY result');
        return;
      }

      console.log('[SubtitleMate] bridge result -> ' + JSON.stringify(result));
      if (result && result.ok) {
        applied = true;
        appliedVideoId = currentVideoId();
        // Stop further automatic triggers once successfully applied.
        try { observer.disconnect(); } catch (_) {}
        console.log('[SubtitleMate] success: ' + result.info);
        return;
      }

      const info = (result && result.info) || 'unknown';
      console.log('[SubtitleMate] failed: ' + info);

      // Definitive answer: this video has no caption tracks at all. The bridge
      // already waited internally for tracks to appear, so this is not a timing
      // hiccup — keep whatever speed we applied above and stop retrying
      // captions, so no-subtitle videos are never hammered.
      if (/no caption tracks/i.test(info)) {
        applied = true;
        appliedVideoId = currentVideoId();
        try { observer.disconnect(); } catch (_) {}
        console.log('[SubtitleMate] no subtitle tracks on this video; speed-only, stopping retries');
        return;
      }

      // Otherwise: let the caller retry (bounded by the configured retry count).
      console.log('[SubtitleMate] hint: open DevTools console and look for "[SubtitleMate] tracklist" + "[SubtitleMate] api: verify" lines to diagnose.');
    } finally {
      applying = false;
    }
  }

  // Reset the per-video state. Only clears when the video id actually changed,
  // so manual edits within the same video are never re-applied.
  function reset() {
    const vid = currentVideoId();
    if (appliedVideoId !== vid) {
      applied = false;
      appliedVideoId = null;
      speedApplied = false;
    }
    // Re-enable observer in case it was disconnected after a previous success.
    if (!applied) {
      try { observer.observe(document.documentElement, { childList: true, subtree: true }); } catch (_) {}
    }
  }



  function currentVideoId() {
    const m = location.href.match(/[?&]v=([^&]+)/);
    return m ? m[1] : location.pathname;
  }

  function abortCurrentRun() {
    if (currentRunToken) currentRunToken.aborted = true;
  }

  function requestRun() {
    pendingRun = true;
    abortCurrentRun();
    clearTimeout(navigateDebounceTimer);
    navigateDebounceTimer = setTimeout(() => { reset(); runWithRetries(); }, 100);
  }

  async function runWithRetries() {
    if (running) { pendingRun = true; return; }
    if (applied || !isEnabled()) { pendingRun = false; return; }
    running = true;
    pendingRun = false;
    abortCurrentRun();
    const token = { aborted: false };
    currentRunToken = token;
    try {
      // Retry count is user-configurable in the popup (default 5). Stop early
      // on success, abort, or definitive failure so we never hammer YouTube
      // forever.
      const maxRetries = Math.max(1, Math.min(20, Number(settings && settings[K.RETRY_COUNT]) || 5));
      for (let i = 0; i < maxRetries; i++) {
        if (token.aborted) break;
        await applyOnce();
        if (applied || token.aborted) break;
        await sleep(2000);
      }
      // Exhausted retries without success -> definitive failure.
      if (!applied && !token.aborted) {
        console.log('[SubtitleMate] failed after retries; applied=' + applied);
      }
    } finally {
      running = false;
      if (currentRunToken === token) currentRunToken = null;
      if (pendingRun) {
        pendingRun = false;
        setTimeout(() => { reset(); runWithRetries(); }, 50);
      }
    }
  }

  // ---------- listeners ----------

  window.addEventListener('message', (event) => {
    const data = event.data;
    if (!data || data.source !== 'subtitlemate-bridge') return;
    if (data.type === 'READY') {
      bridgeReady = true;
      console.log('[SubtitleMate] bridge reported ready');
    }
  });

  // React to settings updates from popup.
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg && msg.type === 'SM_SETTINGS_CHANGED') {
      settings = msg.settings;

      // Always force re-evaluation when settings change; the target may have changed.
      applied = false;
      appliedVideoId = null;
      speedApplied = false;
      try {
        observer.observe(document.documentElement, { childList: true, subtree: true });
      } catch (_) {}
      requestRun();
    }
  });

  // React to YouTube SPA navigation (switching videos).
  window.addEventListener('yt-navigate-finish', () => {
    requestRun();
  });

  // Watch for the video element being injected (run_at: document_start).
  function getVideo() {
    return document.querySelector('video.html5-main-video') ||
           document.querySelector('#movie_player video') ||
           document.querySelector('video');
  }

  let observerCooldownUntil = 0;
  const observer = new MutationObserver(() => {
    if (applied || !isEnabled() || !getVideo()) return;
    const now = Date.now();
    // Throttle DOM-triggered runs: at most one every 2s, so a burst of
    // YouTube DOM mutations can't spam runWithRetries.
    if (now < observerCooldownUntil) return;
    observerCooldownUntil = now + 2000;
    runWithRetries();
  });
  observer.observe(document.documentElement, { childList: true, subtree: true });

  async function init() {
    await loadSettings();
    injectBridge();
    runWithRetries();
  }

  init();
})();
