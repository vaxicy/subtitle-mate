#!/usr/bin/env python3
"""Generate SubtitleMate store assets: icons, bilingual promo, screenshots.

Colors match popup.css (red brand).
Outputs:
  icons/icon16.png, icon48.png, icon128.png
  store-assets/promo/440x280.png, 1400x560.png (bilingual EN + 中文 in one image)
  store-assets/screenshots/{zh,en}/screenshot-*.png (1280x800 RGB)
"""
import os
import numpy as np
from PIL import Image, ImageDraw, ImageFont

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ICONS = os.path.join(ROOT, "icons")
PROMO = os.path.join(ROOT, "store-assets", "promo")
SHOTS = os.path.join(ROOT, "store-assets", "screenshots")

# Brand colors from popup.css
PRIMARY = (0xE5, 0x39, 0x35)      # #E53935
ACCENT = (0xFF, 0x3B, 0x30)       # #FF3B30
WHITE = (0xFF, 0xFF, 0xFF)
TEXT = (0x1F, 0x1F, 0x1F)
SECONDARY = (0x75, 0x75, 0x75)
SURFACE = (0xFF, 0xF5, 0xF5)
BORDER = (0xFF, 0xE0, 0xE0)
SOFT_BG = (0xF5, 0xF6, 0xFA)
STAGE_BG = (0x0F, 0x0F, 0x13)

FONT_DIR = r"C:\Windows\Fonts"
F_REG = os.path.join(FONT_DIR, "segoeui.ttf")
F_BOLD = os.path.join(FONT_DIR, "segoeuib.ttf")
F_CJK = os.path.join(FONT_DIR, "msyh.ttc")  # Microsoft YaHei


def font(size, bold=False, cjk=False):
    try:
        if cjk:
            return ImageFont.truetype(F_CJK, size)
        return ImageFont.truetype(F_BOLD if bold else F_REG, size)
    except Exception:
        return ImageFont.load_default()


def draw_center(d, cx, cy, s, f, fill):
    b = d.textbbox((0, 0), s, font=f)
    w = b[2] - b[0]
    h = b[3] - b[1]
    d.text((cx - w / 2 - b[0], cy - h / 2 - b[1]), s, font=f, fill=fill)


def wrap_text(d, text, f, max_w):
    """Simple greedy text wrap for a single line width."""
    words = text.split()
    lines = []
    cur = ""
    for w in words:
        test = cur + (" " if cur else "") + w
        bw = d.textbbox((0, 0), test, font=f)[2]
        if bw <= max_w:
            cur = test
        else:
            if cur:
                lines.append(cur)
            cur = w
    if cur:
        lines.append(cur)
    return lines


def wrap_text_cjk(d, text, f, max_w):
    """Wrap CJK text by characters, greedy."""
    lines = []
    cur = ""
    for ch in text:
        test = cur + ch
        bw = d.textbbox((0, 0), test, font=f)[2]
        if bw <= max_w:
            cur = test
        else:
            if cur:
                lines.append(cur)
            cur = ch
    if cur:
        lines.append(cur)
    return lines


# ---------- Icons ----------
# Use icon-source.png as the single source of truth; auto-matte white background to transparent.
ICON_SOURCE = os.path.join(ROOT, "store-assets", "icon-source.png")
_source_icon = None
_source_icon_no_bg = None


def remove_background(img_rgba, tolerance=35, edge_expand=2):
    """Remove only the edge-connected background, preserving internal whites.

    Flood-fills from the image border so isolated white areas inside the icon
    (e.g. speech-bubble fill, letter counters) stay opaque.
    """
    from collections import deque

    w, h = img_rgba.size
    # Pillow 10+ deprecates getdata(); use get_flattened_data when available.
    try:
        px = list(img_rgba.get_flattened_data())
    except AttributeError:
        px = list(img_rgba.getdata())

    # Reference background colour from the four corners.
    corners = [(0, 0), (w - 1, 0), (0, h - 1), (w - 1, h - 1)]
    bg_r = sum(px[y * w + x][0] for x, y in corners) // 4
    bg_g = sum(px[y * w + x][1] for x, y in corners) // 4
    bg_b = sum(px[y * w + x][2] for x, y in corners) // 4

    def is_bg(idx):
        r, g, b, _ = px[idx]
        return (abs(r - bg_r) <= tolerance and
                abs(g - bg_g) <= tolerance and
                abs(b - bg_b) <= tolerance)

    mask = [False] * (w * h)
    q = deque()

    # Seed every border pixel.
    for y in range(h):
        for x in (0, w - 1):
            idx = y * w + x
            if not mask[idx] and is_bg(idx):
                mask[idx] = True
                q.append(idx)
    for x in range(1, w - 1):
        for y in (0, h - 1):
            idx = y * w + x
            if not mask[idx] and is_bg(idx):
                mask[idx] = True
                q.append(idx)

    # 8-direction flood fill.
    while q:
        idx = q.popleft()
        x = idx % w
        y = idx // w
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                if dx == 0 and dy == 0:
                    continue
                nx, ny = x + dx, y + dy
                if 0 <= nx < w and 0 <= ny < h:
                    nidx = ny * w + nx
                    if not mask[nidx] and is_bg(nidx):
                        mask[nidx] = True
                        q.append(nidx)

    # Expand the mask by a couple of pixels to clean anti-aliased white fringe
    # without touching icon content that is not connected to the background.
    if edge_expand > 0:
        new_mask = mask[:]
        for y in range(h):
            for x in range(w):
                idx = y * w + x
                if mask[idx] or not is_bg(idx):
                    continue
                for dx in range(-edge_expand, edge_expand + 1):
                    for dy in range(-edge_expand, edge_expand + 1):
                        nx, ny = x + dx, y + dy
                        if 0 <= nx < w and 0 <= ny < h and mask[ny * w + nx]:
                            new_mask[idx] = True
                            break
                    if new_mask[idx]:
                        break
        mask = new_mask

    new = [(r, g, b, 0) if mask[i] else (r, g, b, a)
           for i, (r, g, b, a) in enumerate(px)]
    img_rgba.putdata(new)
    return img_rgba


def remove_star_component(img_rgba):
    """Remove the small decorative star in the top-right corner.

    After background removal the star is a separate connected component
    above and to the right of the main speech-bubble icon.
    """
    from collections import deque

    arr = np.array(img_rgba)
    h, w = arr.shape[:2]
    opaque = arr[:, :, 3] > 0
    visited = np.zeros((h, w), dtype=bool)
    largest_size = 0
    components = []

    for y in range(h):
        for x in range(w):
            if opaque[y, x] and not visited[y, x]:
                comp = []
                q = deque([(x, y)])
                visited[y, x] = True
                while q:
                    cx, cy = q.popleft()
                    comp.append((cx, cy))
                    for dx in (-1, 0, 1):
                        for dy in (-1, 0, 1):
                            if dx == 0 and dy == 0:
                                continue
                            nx, ny = cx + dx, cy + dy
                            if 0 <= nx < w and 0 <= ny < h and opaque[ny, nx] and not visited[ny, nx]:
                                visited[ny, nx] = True
                                q.append((nx, ny))
                largest_size = max(largest_size, len(comp))
                components.append(comp)

    star_mask = np.zeros((h, w), dtype=bool)
    for comp in components:
        size = len(comp)
        if size == 0:
            continue
        cx = sum(p[0] for p in comp) / size
        cy = sum(p[1] for p in comp) / size
        # Star is a small isolated component in the top-right quadrant.
        if size < largest_size * 0.05 and cx > w * 0.70 and cy < h * 0.25:
            for x, y in comp:
                star_mask[y, x] = True

    arr[star_mask] = [0, 0, 0, 0]
    return Image.fromarray(arr, "RGBA")


def load_source_icon():
    global _source_icon_no_bg
    if _source_icon_no_bg is None:
        img = Image.open(ICON_SOURCE).convert("RGBA")
        _source_icon_no_bg = remove_star_component(remove_background(img))
    return _source_icon_no_bg


def make_icon(size):
    return load_source_icon().resize((size, size), Image.LANCZOS)


def make_toolbar_icon(source, target_size=16, fill_ratio=0.92):
    alpha = source.split()[-1]
    bbox = alpha.getbbox()
    if not bbox:
        return source.resize((target_size, target_size), Image.LANCZOS)
    content = source.crop(bbox)
    cw, ch = content.size
    scale = (target_size * fill_ratio) / max(cw, ch)
    new_w = max(1, int(round(cw * scale)))
    new_h = max(1, int(round(ch * scale)))
    scaled = content.resize((new_w, new_h), Image.LANCZOS)
    canvas = Image.new("RGBA", (target_size, target_size), (0, 0, 0, 0))
    x = (target_size - new_w) // 2
    y = (target_size - new_h) // 2
    canvas.paste(scaled, (x, y), scaled)
    return canvas


def gen_icons():
    os.makedirs(ICONS, exist_ok=True)
    src = load_source_icon()
    for s in (128, 48):
        src.resize((s, s), Image.LANCZOS).save(os.path.join(ICONS, f"icon{s}.png"), "PNG")
    make_toolbar_icon(src, 16, fill_ratio=0.92).save(os.path.join(ICONS, "icon16.png"), "PNG")
    print("icons generated")


# ---------- Promo ----------
def rounded_card(d, box, radius, fill):
    d.rounded_rectangle(box, radius=radius, fill=fill)


def draw_promo(w, h, filepath):
    """Draw bilingual promo tile with size-aware absolute positioning."""
    is_small = (w == 440)
    scale = w / 1400.0
    img = Image.new("RGB", (w, h), WHITE)
    d = ImageDraw.Draw(img)

    panel_w = int(w * 0.42)
    d.rectangle([0, 0, panel_w, h], fill=PRIMARY)

    # Decorative accents
    d.ellipse([panel_w - int(80*scale), h - int(110*scale), panel_w - int(20*scale), h - int(50*scale)], fill=ACCENT)
    d.ellipse([int(20*scale), h - int(80*scale), int(70*scale), h - int(30*scale)], fill=(0xF5, 0x6A, 0x6A))

    # Icon on a white rounded card for contrast against the red panel
    if is_small:
        ic_sz = int(54 * scale * (1400/440))
        pad = int(10 * scale * (1400/440))
    else:
        ic_sz = int(120 * scale)
        pad = int(18 * scale)
    card_x = int(36 * scale)
    card_y = int(36 * scale)
    card_sz = ic_sz + pad * 2
    card_radius = int(card_sz * 0.22)
    rounded_card(d, [card_x, card_y, card_x + card_sz, card_y + card_sz], card_radius, WHITE)
    ic = make_icon(ic_sz)
    img.paste(ic, (card_x + pad, card_y + pad), ic)

    # Title — placed below the icon card (English brand name only)
    title_en = "SubtitleMate"
    ty = card_y + card_sz + int(44 * scale)
    draw_center(d, panel_w/2, ty, title_en, font(int(34*scale), bold=True), WHITE)

    # Right side: headline + CTA
    rx = panel_w + int(48*scale)
    hy = int(80*scale)
    headline_en = "Captions + custom speed"
    headline_zh = "字幕 + 自定义倍速"
    if is_small:
        d.text((rx, hy), headline_en, font=font(int(16*scale*(1400/440)), bold=True), fill=TEXT)
        d.text((rx, hy + int(22*scale*(1400/440))), headline_zh, font=font(int(13*scale*(1400/440)), cjk=True), fill=SECONDARY)
        btn_w, btn_h = int(140*scale*(1400/440)), int(34*scale*(1400/440))
        btn_y = h - int(26*scale*(1400/440)) - btn_h
        rounded_card(d, [rx, btn_y, rx + btn_w, btn_y + btn_h], int(7*scale*(1400/440)), PRIMARY)
        bcx = rx + btn_w/2
        bcy = btn_y + btn_h/2 - int(5*scale*(1400/440))
        draw_center(d, bcx, bcy, "Add", font(int(12*scale*(1400/440)), bold=True), WHITE)
        draw_center(d, bcx, bcy + int(12*scale*(1400/440)), "添加", font(int(10*scale*(1400/440)), cjk=True), (255, 220, 220))
    else:
        d.text((rx, hy), headline_en, font=font(int(26*scale), bold=True), fill=TEXT)
        d.text((rx, hy + int(34*scale)), headline_zh, font=font(int(20*scale), cjk=True), fill=SECONDARY)
        sub_en = "Set it once — captions and playback speed on every video."
        sub_zh = "一次设置，每部视频自动出字幕、自动调倍速。"
        sy = hy + int(78*scale)
        d.text((rx, sy), sub_en, font=font(int(15*scale)), fill=SECONDARY)
        d.text((rx, sy + int(22*scale)), sub_zh, font=font(int(15*scale), cjk=True), fill=SECONDARY)
        btn_w, btn_h = int(220*scale), int(48*scale)
        btn_y = h - int(56*scale) - btn_h
        rounded_card(d, [rx, btn_y, rx + btn_w, btn_y + btn_h], int(10*scale), PRIMARY)
        bcx = rx + btn_w/2
        bcy = btn_y + btn_h/2 - int(8*scale)
        draw_center(d, bcx, bcy, "Add to Chrome", font(int(18*scale), bold=True), WHITE)
        draw_center(d, bcx, bcy + int(20*scale), "添加到 Chrome", font(int(14*scale), cjk=True), (255, 220, 220))

    img.save(filepath, "PNG")


def gen_promo():
    os.makedirs(PROMO, exist_ok=True)
    draw_promo(440, 280, os.path.join(PROMO, "440x280.png"))
    draw_promo(1400, 560, os.path.join(PROMO, "1400x560.png"))
    print("promo generated")


# ---------- Popup mockup ----------
def draw_popup_mock(lang):
    """Render the popup UI mockup card (transparent bg) used in screenshots.

    Layout mirrors the real popup.html order exactly:
      1. Enable SubtitleMate (master toggle + hint)
      2. Auto-click CC button on video pages (checkbox + hint)
      3. Auto-set playback speed (checkbox)
      4. divider
      5. Caption mode (select)
      6. Translate to (select + hint, shown because mode is Auto-translate)
      7. Playback speed (select)
      8. Support the developer
    """
    scale = 1.25
    card_w = int(230 * scale)
    pad = int(10 * scale)
    inner_x = pad
    inner_w = card_w - 2 * pad

    en = (lang == 'en')

    # helper: chevron at right edge of a select box of given top y / height
    def chevron(cx, cy, r):
        d.polygon([(cx-r, cy-r+1), (cx, cy+r+1), (cx+r, cy-r+1)], fill=SECONDARY)

    # ---- measure height top-down ----
    y = 0
    y += int(22 * scale)          # top padding
    y += int(30 * scale)          # header
    y += int(6 * scale)           # margin
    y += int(52 * scale)          # master toggle row (title + hint + toggle)
    y += int(6 * scale)           # margin
    y += int(62 * scale)          # checkbox 1 (text + 2-line hint)
    y += int(2 * scale)           # margin
    y += int(24 * scale)          # checkbox 2 (single line)
    y += int(8 * scale)           # margin
    y += int(16 * scale)          # divider
    y += int(58 * scale)          # caption mode block (label + select)
    y += int(6 * scale)           # margin
    y += int(70 * scale)          # translate-to block (label + hint + select)
    y += int(6 * scale)           # margin
    y += int(58 * scale)          # playback speed block (label + select)
    y += int(10 * scale)          # margin
    y += int(16 * scale)          # support divider
    y += int(16 * scale)          # support link
    y += int(14 * scale)          # bottom padding
    card_h = y

    img = Image.new("RGBA", (card_w, card_h), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    rounded_card(d, [0, 0, card_w, card_h], int(10*scale), WHITE)

    y = int(22 * scale)

    # header
    ic = make_icon(int(22*scale))
    img.paste(ic, (inner_x, y), ic)
    name = "SubtitleMate"
    d.text((inner_x + int(28*scale), y + int(4*scale)), name,
           font=font(int(15*scale), bold=True, cjk=not en), fill=TEXT)
    switch_w = int(58 * scale)
    switch_h = int(22 * scale)
    switch_x = card_w - pad - switch_w
    rounded_card(d, [switch_x, y, switch_x + switch_w, y + switch_h], int(6*scale), SURFACE)
    d.rectangle([switch_x, y, switch_x + switch_w, y + switch_h], outline=BORDER, width=1)
    d.text((switch_x + int(8*scale), y + int(4*scale)), "EN / 中文",
           font=font(int(10*scale), cjk=True), fill=SECONDARY)
    y += int(30 * scale) + int(6 * scale)

    # 1. master toggle row
    lbl = "Enable SubtitleMate" if en else "启用 SubtitleMate"
    d.text((inner_x, y), lbl, font=font(int(15*scale), bold=True, cjk=not en), fill=TEXT)
    hint = "Master switch for this extension" if en else "扩展总开关"
    d.text((inner_x, y + int(20*scale)), hint, font=font(int(10*scale), cjk=not en), fill=SECONDARY)
    tw, th = int(40*scale), int(22*scale)
    tx = inner_x + inner_w - tw
    ty = y + int(2*scale)
    d.rounded_rectangle([tx, ty, tx+tw, ty+th], int(th/2), fill=PRIMARY)
    d.ellipse([tx+tw-th+2, ty+2, tx+tw-2, ty+th-2], fill=WHITE)
    y += int(52 * scale) + int(6 * scale)

    # 2. checkbox 1 (with hint)
    chk1 = "Auto-click CC button on video pages" if en else "进入视频页自动点击字幕按钮"
    chk1hint = 'Automatically clicks the "CC" button in the YouTube player' if en else '检测到 YouTube 视频时，自动点击播放器右下角“CC”按钮'
    d.rounded_rectangle([inner_x, y, inner_x + int(16*scale), y + int(16*scale)], int(3*scale), fill=PRIMARY)
    d.line([(inner_x+int(5*scale), y+int(8*scale)), (inner_x+int(8*scale), y+int(12*scale))], fill=WHITE, width=max(1, int(2*scale)))
    d.line([(inner_x+int(8*scale), y+int(12*scale)), (inner_x+int(13*scale), y+int(5*scale))], fill=WHITE, width=max(1, int(2*scale)))
    d.text((inner_x + int(24*scale), y - int(2*scale)), chk1, font=font(int(12*scale), cjk=not en), fill=TEXT)
    hint_font = font(int(9*scale), cjk=not en)
    hint_lines = (['Automatically clicks the "CC" button', 'in the YouTube player']
                  if en else ['检测到 YouTube 视频时，自动点击', '播放器右下角“CC”按钮'])
    hy = y + int(16*scale)
    for line in hint_lines:
        d.text((inner_x + int(24*scale), hy), line, font=hint_font, fill=SECONDARY)
        hy += int(12*scale)
    y += int(62 * scale) + int(2 * scale)

    # 3. checkbox 2 (single line)
    chk2 = "Auto-set playback speed" if en else "自动设置播放速度"
    d.rounded_rectangle([inner_x, y + int(2*scale), inner_x + int(16*scale), y + int(18*scale)], int(3*scale), fill=WHITE)
    d.rectangle([inner_x, y + int(2*scale), inner_x + int(16*scale), y + int(18*scale)], outline=SECONDARY, width=1)
    d.text((inner_x + int(24*scale), y), chk2, font=font(int(12*scale), cjk=not en), fill=TEXT)
    y += int(24 * scale) + int(8 * scale)

    # divider
    y += int(4 * scale)
    d.line([(inner_x, y), (inner_x + inner_w, y)], fill=BORDER, width=1)
    y += int(12 * scale)

    # 5. caption mode block
    d.text((inner_x, y), "Caption mode" if en else "字幕模式",
           font=font(int(11*scale), cjk=not en), fill=SECONDARY)
    y += int(20 * scale)
    rounded_card(d, [inner_x, y, inner_x + inner_w, y + int(38*scale)], int(8*scale), WHITE)
    d.rectangle([inner_x, y, inner_x + inner_w, y + int(38*scale)], outline=BORDER, width=1)
    cm_text = "Auto-translate" if en else "自动翻译"
    d.text((inner_x + int(10*scale), y + int(10*scale)), cm_text,
           font=font(int(13*scale), cjk=not en), fill=TEXT)
    cx = inner_x + inner_w - int(18*scale)
    cy = y + int(19*scale)
    chevron(cx, cy, int(4*scale))
    y += int(38 * scale) + int(6 * scale)

    # 6. translate-to block
    d.text((inner_x, y), "Translate to" if en else "翻译为",
           font=font(int(11*scale), cjk=not en), fill=SECONDARY)
    y += int(14 * scale)
    hint = 'Used when caption mode is "Auto-translate"' if en else "仅在「自动翻译」模式下生效"
    d.text((inner_x, y), hint, font=font(int(10*scale), cjk=not en), fill=SECONDARY)
    y += int(20 * scale)
    rounded_card(d, [inner_x, y, inner_x + inner_w, y + int(38*scale)], int(8*scale), WHITE)
    d.rectangle([inner_x, y, inner_x + inner_w, y + int(38*scale)], outline=BORDER, width=1)
    tl_text = "Chinese (Simplified)" if en else "中文（简体）"
    d.text((inner_x + int(10*scale), y + int(10*scale)), tl_text,
           font=font(int(13*scale), cjk=not en), fill=TEXT)
    chevron(cx, cy, int(4*scale))
    y += int(38 * scale) + int(6 * scale)

    # 7. playback speed block
    d.text((inner_x, y), "Playback speed" if en else "播放速度",
           font=font(int(11*scale), cjk=not en), fill=SECONDARY)
    y += int(20 * scale)
    rounded_card(d, [inner_x, y, inner_x + inner_w, y + int(38*scale)], int(8*scale), WHITE)
    d.rectangle([inner_x, y, inner_x + inner_w, y + int(38*scale)], outline=BORDER, width=1)
    sp_text = "1.5x" if en else "1.5 倍速"
    d.text((inner_x + int(10*scale), y + int(10*scale)), sp_text,
           font=font(int(13*scale), cjk=not en), fill=TEXT)
    chevron(cx, cy, int(4*scale))
    y += int(38 * scale)

    # 8. support
    y += int(10 * scale)
    d.line([(inner_x, y), (inner_x + inner_w, y)], fill=BORDER, width=1)
    y += int(10 * scale)
    support_text = "Support the developer" if en else "支持开发者"
    b = d.textbbox((0, 0), support_text, font=font(int(11*scale), cjk=not en))
    sw = b[2] - b[0]
    d.text((inner_x + (inner_w - sw) // 2, y), support_text, font=font(int(11*scale), cjk=not en), fill=SECONDARY)

    return img


# ---------- Screenshots ----------
def draw_browser_stage(d, W, H):
    """Draw a generic browser chrome + YouTube video stage."""
    # Browser toolbar
    toolbar_h = int(48)
    d.rectangle([0, 0, W, toolbar_h], fill=(0xDE, 0xDF, 0xE6))
    d.rounded_rectangle([int(16), int(12), int(700), int(36)], int(8), fill=WHITE)
    d.text((int(28), int(16)), "youtube.com/watch", font=font(14), fill=SECONDARY)
    # Window controls dots
    dot_colors = [(0xFF, 0x5F, 0x56), (0xFF, 0xBD, 0x2E), (0x28, 0xC8, 0x40)]
    for i, col in enumerate(dot_colors):
        d.ellipse([int(1160 + i*20), int(18), int(1160 + i*20 + 12), int(30)], fill=col)

    # Video stage
    stage = [int(60), int(80), W - int(60), int(470)]
    d.rectangle(stage, fill=STAGE_BG)
    ic = make_icon(48)
    d._image.paste(ic, (W//2 - 24, int(250)), ic)
    return stage


def draw_caption_bar(d, stage, lang, caption_text):
    """Draw a YouTube-style caption bar inside the video stage."""
    W = d._image.width
    cb_y = stage[3] - int(90)
    cb_h = int(44)
    cb_w = min(int(680), W - int(240))
    cb_x = (W - cb_w) // 2
    d.rounded_rectangle([cb_x, cb_y, cb_x + cb_w, cb_y + cb_h], int(8), fill=(0, 0, 0))
    draw_center(d, W//2, cb_y + cb_h//2, caption_text, font(17, cjk=(lang=='zh')), WHITE)


def draw_speed_badge(d, stage, lang):
    """Draw a YouTube-style playback speed badge in the video stage."""
    W = d._image.width
    bx = stage[2] - int(120)
    by = stage[1] + int(20)
    bw, bh = int(96), int(34)
    d.rounded_rectangle([bx, by, bx + bw, by + bh], int(8), fill=(0, 0, 0))
    speed_text = "1.5x" if lang == 'en' else "1.5 倍速"
    draw_center(d, bx + bw/2, by + bh/2, speed_text, font(16, cjk=(lang=='zh')), WHITE)


def gen_screenshots():
    scenes = {
        "screenshot-1-browser.png": {
            "en": {
                "caption": "Open a YouTube video — captions turn on automatically",
                "bottom": "Auto-enable YouTube captions with one click",
            },
            "zh": {
                "caption": "打开 YouTube 视频 — 字幕自动开启",
                "bottom": "一键自动开启 YouTube 字幕",
            },
        },
        "screenshot-2-translate.png": {
            "en": {
                "caption": "Auto-opened captions appear instantly",
                "bottom": "Automatically open captions in your preferred language",
            },
            "zh": {
                "caption": "字幕自动呈现",
                "bottom": "按偏好自动打开对应语言字幕",
            },
        },
        "screenshot-3-autogen.png": {
            "en": {
                "caption": "English (auto-generated) captions ready to go",
                "bottom": "Switch to auto-generated captions when you prefer",
            },
            "zh": {
                "caption": "英语（自动生成）字幕随时可用",
                "bottom": "需要时直接启用自动生成字幕",
            },
        },
        "screenshot-4-speed.png": {
            "en": {
                "caption": "Playback speed snaps to your preset on every video",
                "bottom": "Auto-set a custom playback speed once, applied to all videos",
            },
            "zh": {
                "caption": "每部视频自动套用你预设的播放速度",
                "bottom": "一次设置自定义倍速，所有视频自动生效",
            },
        },
    }
    W, H = 1280, 800
    for lang in ("en", "zh"):
        out_dir = os.path.join(SHOTS, lang)
        os.makedirs(out_dir, exist_ok=True)
        for fname, texts in scenes.items():
            img = Image.new("RGB", (W, H), SOFT_BG)
            d = ImageDraw.Draw(img)
            stage = draw_browser_stage(d, W, H)
            t = texts[lang]
            draw_caption_bar(d, stage, lang, t["caption"])
            if fname == "screenshot-4-speed.png":
                draw_speed_badge(d, stage, lang)

            # Popup mock floating bottom-right
            popup = draw_popup_mock(lang)
            px = W - popup.width - int(50)
            py = H - popup.height - int(80)
            img.paste(popup, (px, py), popup)

            # Bottom description
            d.text((int(80), H - int(60)), t["bottom"],
                   font=font(18, cjk=(lang=='zh')), fill=TEXT)

            img.save(os.path.join(out_dir, fname), "PNG")
        print(f"screenshots generated: {lang}")


if __name__ == "__main__":
    gen_icons()
    gen_promo()
    gen_screenshots()
    print("ALL ASSETS DONE")
